package com.minor;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // JDBC credentials
    private static final String JDBC_URL = "jdbc:mysql://localhost:3307/edification";
    private static final String JDBC_USER = "root"; // Replace with your DB username
    private static final String JDBC_PASSWORD = "major"; // Replace with your DB password

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        // Retrieve form data
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Database connection and query
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Prepare SQL query
            String sql = "SELECT * FROM user WHERE email = ? AND password = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, email);
                pstmt.setString(2, password);

                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        // User found, login successful
                        String fullName = rs.getString("fullname");

                        // Start a session for 12 hours (43200 seconds)
                        HttpSession session = request.getSession();
                        session.setMaxInactiveInterval(12 * 60 * 60); // 12 hours in seconds
                        session.setAttribute("email", email);
                        session.setAttribute("fullName", fullName);

                        // Pass success message to JSP
                        request.setAttribute("message", "Login successful! Redirecting to homepage...");
                        request.setAttribute("success", "true");
                    } else {
                        // User not found, login failed
                        request.setAttribute("message", "Invalid email or password.");
                        request.setAttribute("success", "false");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "An error occurred. Please try again later.");
            request.setAttribute("success", "false");
        }

        // Forward to login.jsp
        request.getRequestDispatcher("login.jsp").forward(request, response);
    }
}
