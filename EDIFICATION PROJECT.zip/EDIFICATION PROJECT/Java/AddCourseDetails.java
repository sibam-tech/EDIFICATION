package com.minor;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class AddCourseDetails
 */
@WebServlet("/addcourse")
public class AddCourseDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCourseDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String jdbcURL = "jdbc:mysql://localhost:3306/edification";
        String jdbcUsername = "root";
        String jdbcPassword = "major";
        System.out.println("hello");

        // Retrieve form data from the request
        String courseName = request.getParameter("course-name");
        String courseImage = request.getParameter("course-image");
        String coursePrice = request.getParameter("course-price");
        String courseDuration = request.getParameter("course-duration");
        String courseRating = request.getParameter("course-rating");
        String courseComments = request.getParameter("course-comments");
        String courseLikes = request.getParameter("course-likes");
        String courseDescription = request.getParameter("course-description");

        // SQL query to insert data into the courses table
        String insertQuery = "INSERT INTO courses (course_name, course_img, course_pr, course_dur, course_rt, course_cmnt, course_like, course_desc) "
                           + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try 
        {
        	
        		Class.forName("com.mysql.cj.jdbc.Driver");

    		
        	Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement statement = connection.prepareStatement(insertQuery);

            // Set parameters for the SQL query
            statement.setString(1, courseName);
            statement.setString(2, courseImage);
            statement.setString(3, coursePrice);
            statement.setString(4, courseDuration);
            statement.setInt(5, Integer.parseInt(courseRating));
            statement.setInt(6, Integer.parseInt(courseComments));
            statement.setInt(7, Integer.parseInt(courseLikes));
            statement.setString(8, courseDescription);

            // Execute the query
            int rowsInserted = statement.executeUpdate();

            // Prepare a JSON response

            if (rowsInserted > 0) {
                response.sendRedirect("adminpanel.jsp?msg=success");
            } else {
            	response.sendRedirect("adminpanel.jsp?msg=failed");
            }

            

        } catch (Exception e) {
           System.out.println(e);
        }
	}

}
