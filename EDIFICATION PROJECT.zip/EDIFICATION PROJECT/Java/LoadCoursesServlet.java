package com.minor;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// Course model class
@WebServlet("/LoadCourses")
public class LoadCoursesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();

        String jdbcURL = "jdbc:mysql://localhost:3306/edification";
        String jdbcUsername = "root";
        String jdbcPassword = "major";

        JsonObject jsonResponse = new JsonObject();
        JsonArray courses = new JsonArray();

        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM courses")) {
        	
            while (resultSet.next()) {
            	JsonObject course = new JsonObject();
                course.addProperty("name",resultSet.getString("course_name"));
                course.addProperty("img",resultSet.getString("course_img"));
                course.addProperty("pr",resultSet.getString("course_pr"));
                course.addProperty("dur",resultSet.getString("course_dur"));
                course.addProperty("rt",resultSet.getInt("course_rt"));
                course.addProperty("cmnt",resultSet.getInt("course_cmnt"));
                course.addProperty("like",resultSet.getInt("course_like"));
                course.addProperty("desc",resultSet.getString("course_desc"));
                course.addProperty("link",resultSet.getString("course_link"));
                course.addProperty("tlink",resultSet.getString("thumbnail_link"));
                courses.add(course);
                
            }
            jsonResponse.add("courses",courses);
            response.getWriter().write(jsonResponse.toString());

            // Convert courses list to JSON
            
            

        } catch (Exception e) {
        	e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("message", "An error occurred while loading events.");
        }
    }
}
